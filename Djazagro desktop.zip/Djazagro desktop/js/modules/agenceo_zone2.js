/**
 * Created by Boubou on 28/06/2016.
 */
(function ($) {

$('#zone2 .article-wrapper  .article-title .inside img').appendTo('#zone2 .article-wrapper .article-intro');

})(jQuery);